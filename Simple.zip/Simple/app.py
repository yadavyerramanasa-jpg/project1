import os
from flask import Flask, render_template, request, jsonify
from google import genai

app = Flask(__name__)

# Direct API injection to guarantee authentication mapping
API_KEY = "AIzaSyCeE0dU-wDoSKB1jYe5l37o8Je2a4yCQy8"

try:
    client = genai.Client(api_key=API_KEY)
except Exception as e:
    print(f"❌ SDK Setup Error: {e}")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    
    if not user_message:
        return jsonify({'error': 'No message provided'}), 400
    
    try:
        # Standard implementation matching the latest stable google-genai library specification
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=user_message,
        )
        
        if not response.text:
            return jsonify({'reply': '*Empty payload received. Check safety parameters or prompt criteria.*'})
            
        return jsonify({'reply': response.text})
        
    except Exception as e:
        # Let's inspect the fallback lane just in case your package compilation requires the base namespace context
        try:
            response = client.generate_content(
                model='gemini-2.5-flash',
                contents=user_message,
            )
            return jsonify({'reply': response.text})
        except Exception as fallback_error:
            print(f"\n❌ CRITICAL API EXCEPTION DETECTED: {str(fallback_error)}\n")
            return jsonify({'error': f"API Engine Exception: {str(fallback_error)}"}), 500

if __name__ == '__main__':
    app.run(debug=True)